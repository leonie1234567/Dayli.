# Dayli – Cozy Planner Prototype

Öffne `index.html` in einem Browser. Der Prototyp ist responsive und kann auf einem iPhone-Browser getestet werden.

Enthalten:
- Cozy Planner Startseite
- klassische Wochenansicht mit 05:00–24:00
- Termine mit Titel, Datum, Start/Ende, Kategorie, Notizen und Pastellfarbe
- To-do-Bereiche: Heute, Diese Woche, Sehr wichtig
- erledigte To-dos werden aus der aktiven Liste entfernt
- individuell abhakbare Tagesziele
- frei beschreibbare Notizen
- lokale Speicherung im Browser
- mittleres Widget-Design als Teil des Konzepts

Für eine echte iOS-App wären im nächsten Schritt SwiftUI, Cloud-Sync, iOS-Erinnerungen/Benachrichtigungen und Home-Screen-Widgets anzubinden.
